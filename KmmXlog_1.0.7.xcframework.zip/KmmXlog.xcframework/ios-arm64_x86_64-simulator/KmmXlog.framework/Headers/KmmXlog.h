#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class KmmXlogKmmLogLevel, KmmXlogKmmLog, KmmXlogKotlinEnumCompanion, KmmXlogKotlinEnum<E>, KmmXlogKotlinArray<T>;

@protocol KmmXlogKotlinComparable, KmmXlogKotlinIterator;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface KmmXlogBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface KmmXlogBase (KmmXlogBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface KmmXlogMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface KmmXlogMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorKmmXlogKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface KmmXlogNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface KmmXlogByte : KmmXlogNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface KmmXlogUByte : KmmXlogNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface KmmXlogShort : KmmXlogNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface KmmXlogUShort : KmmXlogNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface KmmXlogInt : KmmXlogNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface KmmXlogUInt : KmmXlogNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface KmmXlogLong : KmmXlogNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface KmmXlogULong : KmmXlogNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface KmmXlogFloat : KmmXlogNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface KmmXlogDouble : KmmXlogNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface KmmXlogBoolean : KmmXlogNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("IKmmLog")))
@protocol KmmXlogIKmmLog
@required
- (void)appenderClose __attribute__((swift_name("appenderClose()")));
- (void)appenderFlushSyncIsSync:(BOOL)isSync __attribute__((swift_name("appenderFlushSync(isSync:)")));
- (void)dTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("d(tag:content:filename:funcname:line:)")));
- (void)eTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("e(tag:content:filename:funcname:line:)")));
- (void)iTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("i(tag:content:filename:funcname:line:)")));
- (void)logLevel:(NSString * _Nullable)level tag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("log(level:tag:content:filename:funcname:line:)")));
- (void)setTagLevelTag:(NSString *)tag level:(KmmXlogKmmLogLevel *)level __attribute__((swift_name("setTagLevel(tag:level:)")));
- (void)vTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("v(tag:content:filename:funcname:line:)")));
- (void)wTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("w(tag:content:filename:funcname:line:)")));
@property NSString *defaultTag __attribute__((swift_name("defaultTag")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KmmLog")))
@interface KmmXlogKmmLog : KmmXlogBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)kmmLog __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KmmXlogKmmLog *shared __attribute__((swift_name("shared")));
- (void)appenderClose __attribute__((swift_name("appenderClose()")));
- (void)appenderFlushSyncIsSync:(BOOL)isSync __attribute__((swift_name("appenderFlushSync(isSync:)")));
- (void)dTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("d(tag:content:filename:funcname:line:)")));
- (void)eTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("e(tag:content:filename:funcname:line:)")));
- (void)iTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("i(tag:content:filename:funcname:line:)")));
- (void)logLevel:(NSString * _Nullable)level tag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("log(level:tag:content:filename:funcname:line:)")));
- (void)setTagLevelTag:(NSString *)tag level:(KmmXlogKmmLogLevel *)level __attribute__((swift_name("setTagLevel(tag:level:)")));
- (void)setupNamePrefix:(NSString *)namePrefix tagPrefix:(NSString * _Nullable)tagPrefix __attribute__((swift_name("setup(namePrefix:tagPrefix:)")));
- (void)vTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("v(tag:content:filename:funcname:line:)")));
- (void)wTag:(NSString * _Nullable)tag content:(NSString *)content filename:(NSString * _Nullable)filename funcname:(NSString * _Nullable)funcname line:(KmmXlogInt * _Nullable)line __attribute__((swift_name("w(tag:content:filename:funcname:line:)")));
@property NSString *defaultTag __attribute__((swift_name("defaultTag")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol KmmXlogKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface KmmXlogKotlinEnum<E> : KmmXlogBase <KmmXlogKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) KmmXlogKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KmmLogLevel")))
@interface KmmXlogKmmLogLevel : KmmXlogKotlinEnum<KmmXlogKmmLogLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmmXlogKmmLogLevel *levelVerbose __attribute__((swift_name("levelVerbose")));
@property (class, readonly) KmmXlogKmmLogLevel *levelDebug __attribute__((swift_name("levelDebug")));
@property (class, readonly) KmmXlogKmmLogLevel *levelInfo __attribute__((swift_name("levelInfo")));
@property (class, readonly) KmmXlogKmmLogLevel *levelWarning __attribute__((swift_name("levelWarning")));
@property (class, readonly) KmmXlogKmmLogLevel *levelError __attribute__((swift_name("levelError")));
@property (class, readonly) KmmXlogKmmLogLevel *levelFatal __attribute__((swift_name("levelFatal")));
@property (class, readonly) KmmXlogKmmLogLevel *levelNone __attribute__((swift_name("levelNone")));
+ (KmmXlogKotlinArray<KmmXlogKmmLogLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<KmmXlogKmmLogLevel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KmmLogKt")))
@interface KmmXlogKmmLogKt : KmmXlogBase
+ (void)initializeMarsXLogLevel:(int32_t)level namePrefix:(NSString *)namePrefix logDir:(NSString *)logDir mode:(int32_t)mode marsKey:(NSString *)marsKey logToConsole:(BOOL)logToConsole tagPrefix:(NSString * _Nullable)tagPrefix __attribute__((swift_name("initializeMarsXLog(level:namePrefix:logDir:mode:marsKey:logToConsole:tagPrefix:)")));
+ (KmmXlogKmmLogLevel *)intLevelToKmmLogLevel:(int32_t)receiver __attribute__((swift_name("intLevelToKmmLogLevel(_:)")));
@property (class, readonly) NSString *iOSKmmLogTag __attribute__((swift_name("iOSKmmLogTag")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface KmmXlogKotlinEnumCompanion : KmmXlogBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KmmXlogKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface KmmXlogKotlinArray<T> : KmmXlogBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(KmmXlogInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<KmmXlogKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol KmmXlogKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
